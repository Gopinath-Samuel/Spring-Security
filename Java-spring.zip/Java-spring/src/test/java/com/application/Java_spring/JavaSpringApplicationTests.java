package com.application.Java_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
